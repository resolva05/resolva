const express = require('express');
const {route, all } = require('express/lib/application')
const Reportinfo = require('../models/Reportinfo');
const async = require('hbs/lib/async');
const Allreports = require('../models/Allreports');
const reportroutes = express.Router()


reportroutes.get ("/reports/all-reports", async (req,res) => {
    const allreports = await Allreports.find()
    res.render("reports/all-reports", {allreports: allreports})
})
reportroutes.get ("/reports/global-abc-market", (req,res) => {
    res.render("reports/global-abc-market.hbs")
})
reportroutes.get ("/reports/global-interactive-display-market", async (req,res) => {
    const reportdetails =  await Reportinfo.find({_id: "64e24146cd2297f26746fbdd"})
    res.render("reports/global-interactive-display-market.hbs", {reportdetails: reportdetails})
})
reportroutes.get ("/reports/global-delivery-drones-market", async (req,res) => {
    const reportdetails =  await Reportinfo.find({_id: "64e265b3ec3409d7dd589e91"})
    res.render("reports/global-delivery-drones-market.hbs", {reportdetails: reportdetails})
})


module.exports = reportroutes