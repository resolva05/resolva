const express = require('express');
const mongoose = require('mongoose');
//const {route} = require('express/lib/application');
const Reportinfo = require('../models/Reportinfo');
const async = require('hbs/lib/async');
const routes = express.Router()


routes.get ("/", (req,res) => {
    res.render("index")
})
routes.get ("/contact", (req,res) => {  
    res.render("contact")
})
routes.get ("/about", (req,res) => {
    res.render("about")
})
routes.get ("/login", (req,res) => {
    res.render("login")
})
routes.get ("/support", (req,res) => {
    res.render("support")
})
routes.get ("/404", (req,res) => {
    res.render("404.html")
})
routes.get ("/policies/privacy-policy", (req,res) => {
    res.render("policies/privacy-policy")
})
routes.get ("/policies/refund-policy", (req,res) => {
    res.render("policies/refund-policy")
})
routes.get ("/policies/terms-of-use", (req,res) => {
    res.render("policies/terms-of-use")
})
routes.get ("/reports/document", (req,res) => {
    res.render("reports/document")
})




module.exports = routes
