const mongoose = require('mongoose')
const Reportinfo = mongoose.Schema({
    reportTitle: String,
    reportID: String,
    publishedYear: String,
    industry: String,
    marketDefinition: String,
    reportDescription: String,
    reportDescriptionImg: String,
    keyStatistics: String,
    covidImpact:String,
    keyParticipant: String,
    keyParticipantImg: String,
    recentDevelopment: String,
    segmentAnalysis: String,
    segmentationAnslysisImg: String
})

module.exports = mongoose.model("reportinfo",Reportinfo)