const mongoose = require('mongoose')
const Allreports = mongoose.Schema({
    reportImg: String,
    reportTitle: String,
    reportID: String,
    baseYear: String,
    forecastYear: String,
    reportDescription: String,
    reportlink: String,
    reportPrice: String,
    reportBuyNowlink: String,
})

module.exports = mongoose.model("allreports",Allreports)