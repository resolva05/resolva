
        <script>
            $(document).ready(function () {
                var $window = $(window)
                var $sidebar = $(".sidebar1")
                var $sidebarHeight = $sidebar.innerHeight()
                var $footerOffsetTop = $("#footer").offset().top
                var $sidebarOffset = $sidebar.offset();

                $window.scroll(function () {
                    if ($window.scrollTop() > ($sidebarOffset.top + 8000)) {
                        $sidebar.addClass("sticky_bar")
                    } else {
                        $sidebar.removeClass("sticky_bar")
                    }

                    var fHight = ($window.scrollTop() + $sidebarHeight)
                    if (fHight > $footerOffsetTop) {
                        $sidebar.css({"top": -($window.scrollTop() + $sidebarHeight - $footerOffsetTop)})
                    } else {
                        $sidebar.css({"top": "80px", })
                    }
                });
            });
        </script>
