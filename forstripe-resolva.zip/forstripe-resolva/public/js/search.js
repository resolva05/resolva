const itemsPerPage = 3; // Number of items to display per page
const websitePages = [
  { title: 'Home', content: 'Welcome to our website...' },
  { title: 'About Us', content: 'Learn about our company...' },
  { title: 'Products', content: 'Explore our range of products...' },
  // Add more pages and their content here
];

const searchInput = document.getElementById('searchInput');
const searchResultsDiv = document.getElementById('searchResults');
const paginationDiv = document.getElementById('pagination');

searchInput.addEventListener('input', handleSearch);

function handleSearch() {
  const searchTerm = searchInput.value.toLowerCase();
  const matchingPages = searchPages(searchTerm);

  displayResults(matchingPages, 1); // Display the first page of results
}

function searchPages(keyword) {
  return websitePages.filter(page => page.content.toLowerCase().includes(keyword));
}

function displayResults(results, currentPage) {
  searchResultsDiv.innerHTML = '';
  paginationDiv.innerHTML = '';

  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentResults = results.slice(startIndex, endIndex);

  if (currentResults.length === 0) {
    searchResultsDiv.innerHTML = '<p>No results found.</p>';
    return;
  }

  currentResults.forEach(result => {
    const resultDiv = document.createElement('div');
    resultDiv.innerHTML = `
      <h3>${result.title}</h3>
      <p>${highlightSearchTerm(result.content, searchInput.value)}</p>
    `;
    searchResultsDiv.appendChild(resultDiv);
  });

  const totalPages = Math.ceil(results.length / itemsPerPage);
  generatePagination(currentPage, totalPages);
}

function highlightSearchTerm(content, searchTerm) {
  const regex = new RegExp(searchTerm, 'gi');
  return content.replace(regex, match => `<span class="highlight">${match}</span>`);
}

function generatePagination(currentPage, totalPages) {
  for (let i = 1; i <= totalPages; i++) {
    const pageButton = document.createElement('button');
    pageButton.textContent = i;
    pageButton.addEventListener('click', () => displayResults(searchPages(searchInput.value.toLowerCase()), i));
    paginationDiv.appendChild(pageButton);
  }
}