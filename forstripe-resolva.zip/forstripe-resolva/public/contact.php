<?php
// Validate reCAPTCHA
$captcha_response = $_POST['g-recaptcha-response'];
$secret_key = '6Lep0ssmAAAAAGoN3vvWN7Qd50Ae5TvW1xZ10BVu'; // Replace with your reCAPTCHA Secret key
$ip = $_SERVER['REMOTE_ADDR'];

$url = 'https://www.google.com/recaptcha/api/siteverify';
$data = [
    'secret' => $secret_key,
    'response' => $captcha_response,
    'remoteip' => $ip
];

$options = [
    'http' => [
        'header' => "Content-type: application/x-www-form-urlencoded\r\n",
        'method' => 'POST',
        'content' => http_build_query($data)
    ]
];

$context = stream_context_create($options);
$result = file_get_contents($url, false, $context);
$response = json_decode($result, true);

if ($response['success'] == false) {
    // CAPTCHA validation failed
    echo 'CAPTCHA verification failed. Please try again.';
    exit;
}

// CAPTCHA validation successful, continue processing the form submission

// Retrieve form data
$name = $_POST['name'];
$email = $_POST['email'];
$message = $_POST['message'];

// TODO: Add your logic to process the form data (e.g., send an email, store in a database, etc.)

// Example: Send an email
$to = 'your_email@example.com'; // Replace with your email address
$subject = 'New Contact Form Submission';
$email_body = "Name: $name\nEmail: $email\nMessage: $message";
$headers = "From: $email";

if (mail($to, $subject, $email_body, $headers)) {
    echo 'Message sent successfully!';
} else {
    echo 'Error sending message. Please try again later.';
}
?>
