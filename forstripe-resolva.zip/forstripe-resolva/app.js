require("dotenv").config();
const express = require('express');
const hbs = require('hbs');
const handlebars = require('express-handlebars');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
var path = require ('path');
const Reportinfo = require("./models/Reportinfo");
const Allreports = require("./models/Allreports");

const https = require('https');
const fs = require('fs');

const app = express()

app.use(bodyParser.urlencoded({extended:true}));

const async = require('hbs/lib/async');
//const routes = express.Router();


const routes = require('./routes/mainroutes')
const reportroutes = require('./routes/reportroutes')


//To tell express that our static folder is public folder
app.use('/static',express.static("public"))
app.use('',routes)
app.use('',reportroutes)


//Database Connection
//mongoose.connect("mongodb://127.0.0.1:27017/resolva-db");
// const MONGO_URL= mongoose.connect(process.env.MONGO_URL)
// .then((e) => console.log('DB Connected Mongo Running'))

//Database Connection
mongoose.connect("mongodb+srv://resolvadb1:mayur512@cluster0.sdq2ljq.mongodb.net/")
.then((e) => console.log('DB Connected Mongo Running'));


// Reportinfo.create({
//     reportTitle: "Interactive Display Market Size, Share & Trends Analysis Report By Display Type (Interactive Kiosk, Interactive Video Wall), By Application (BFSI, Healthcare, Retail), By Region, And Segment Forecasts, 2023 - 2030",
//     reportID: "12345",
//     publishedYear: "2023",
//     industry: "Semiconductor Display",
//     marketDefinition: "An interactive display, also known as an Interactive Flat Panel Display, is a wall-mounted device that allows users to generate spectacular visual presentations and manipulate on-screen data using digital touchscreen inputs.",
//     reportDescription: "The global interactive display market size was valued at USD 41.45 billion in 2022 and is estimated to grow at a compound annual growth rate (CAGR) of 7.8% from 2023 to 2030. The study comprises interactive kiosk, video walls, table, monitors, and whiteboard. The interactive or touchscreen display is a display unit that accepts user commands with the help of a finger or stylus in place of peripheral devices, such as a mouse or keyboard. Additionally, these displays include screens that project information, such as texts, images, and videos. These display screens are used in various industries, such as retail, healthcare, hospitality, and education. The market is expected to witness significant growth in the coming years, primarily owing to increasing demand for digital classrooms as well as growing adoption of these displays, such as video walls and tables. These video walls and tables are used at transit spaces/public transportation, such as railway stations and airports.",
//     reportDescriptionImg: "/static/report_images/sample1.jpg",
//     keyStatistics: "The global interactive display market size was valued at USD 41.45 billion in 2022 and is estimated to grow at a compound annual growth rate (CAGR) of 7.8% from 2023 to 2030. ",
//     covidImpact:"The COVID-19 pandemic has had a significant impact on the interactive display industry, both in the short and long term. With the shift to remote work, remote learning, and virtual meetings, the demand for interactive displays has increased as they offer an immersive and engaging way to communicate and collaborate from a distance. In the short term, the pandemic caused significant disruptions in the supply chain, which in turn led to production delays and increased costs for interactive display manufacturers. With the global spread of the pandemic, many countries implemented lockdowns and restrictions on movement, which had a significant impact on global trade and transportation. This, coupled with the closure of factories and warehouses, led to supply chain disruptions, causing delays in the delivery of raw materials and components necessary for the production of interactive displays. As a result, manufacturers were forced to either delay production or source materials at a higher cost, which ultimately increased the cost of these displays for consumers.",
//     keyParticipant: "Box Light corporation; eyefactive GmbH; HORIZON DISPLAY INC.; IDEUM; LG Display Co.; Marvel Technology (China) Co.,Ltd; MMT GmbH & Co. KG.; Panasonic Corporation; SHARP CORPORATION; TableConnect",
//     keyParticipantImg: "/static/report_images/sample1.jpg",
//     recentDevelopment: " In February 2023, SMART Technologies unveiled its latest interactive displays designed for educational purposes at the TCEA Convention & Exposition held in San Antonio, Texas in 2023. The newest release comprises the SMART Board GX (V2) series and the SMART Board MX (V4) series. With this launch, these new displays are part of the SMART Board 6000S as the first interactive displays that enable multiple users to write, erase, and gesture simultaneously, on any platform and application. ",
//     segmentAnalysis: "In terms of display type, the market is classified into interactive kiosk, video wall, table, display, and whiteboard. The kiosk segment dominated the overall market, gaining a market share of 73.4% in 2022 and witnessing a CAGR of 7.2% during the forecast period. An interactive kiosk is a self-contained electronic device that allows people to interact with it by using a touch screen or other input device. These kiosks can be used for a variety of purposes, such as providing information, selling products, processing transactions, or conducting surveys. The growth of this segment can be attributed to the increasing demand for reciprocal self-services in the retail, transportation, and healthcare sectors. Smart vending machines, Automated Teller Machine (ATMs), and other touch-enabled self-service solutions offer a potential way for companies to deliver good consumer service even during rush business hours. Furthermore, the increasing use of interactive kiosks in the product/service delivery business has allowed companies to deliver tailored plans at low delivery costs to their clients.",
//     segmentationAnslysisImg: "/static/report_images/sample1.jpg"
// })
   
// Allreports.create({
//     reportImg:"/static/img/ES1.jpg",
//     reportTitle: "Interactive Display Market Size, Share & Trends Analysis Report By Display Type (Interactive Kiosk, Interactive Video Wall), By Application (BFSI, Healthcare, Retail), By Region, And Segment Forecasts, 2023 - 2030",
//     reportID: "123450",
//     baseYear: "2022",
//     forecastYear: "2023-2032",
//     reportDescription: "The global interactive display market size was valued at USD 41.45 billion in 2022 and is estimated to grow at a compound annual growth rate (CAGR) of 7.8% from 2023 to 2030.",
//     reportlink: "/reports/interactive-display-market",
//     reportPrice: "$4,250",
//     reportBuyNowlink: "/reports/buynow/interactive-display",
// })



//(hbs Template Engine)
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));
hbs.registerPartials("views/partials");


//Create Data Schema for Contact Form on Index Page
const contactFormSchema = {
    fullName: String,
    businessEmail: String,
    businessPhone: String,
    jobTitle: String,
    company: String,
    topicofInterest: String,
    comment: String,
}

const ContactForm = mongoose.model("ContactForm", contactFormSchema);

//Contact Form Data Route
app.post("/requests/contact-form-submit", function (req,res) {
    let clientData = new ContactForm({
        fullName: req.body.name,
        businessEmail: req.body.businessEmail,
        businessPhone: req.body.businessPhone,
        jobTitle: req.body.jobtitle,
        company: req.body.companyName,
        topicofInterest: req.body.subject,
        comment: req.body.clientComment,
    })

    clientData.save();

    res.render("requests/contact-form-submit");

})


//Create Data Schema for Contact Form on Contact Us Page
const contactFormPage = {
    fullName: String,
    businessEmail: String,
    businessPhone: String,
    jobTitle: String,
    company: String,
    topicofInterest: String,
    comment: String,
}

const ContactFormPage = mongoose.model("ContactFormPage", contactFormPage);

//Contact Form Data Route
app.post("/requests/contact-form-submit-1", function (req,res) {
    let clientContactDetails = new ContactFormPage({
    fullName: req.body.name,
    businessEmail: req.body.businessEmail,
    businessPhone: req.body.businessPhone,
    jobTitle: req.body.jobtitle,
    company: req.body.companyName,
    topicofInterest: req.body.subject,
    comment: req.body.clientComment,
    })

    clientContactDetails.save();

    res.render("requests/contact-form-submit-1");

})

const PORT = process.env.PORT || 443;


// const sslServer = https.createServer ( {
//     key: fs.readFileSync('../resolvainsights.com.pkcs8'),
//     cert: fs.readFileSync('../sslcertifi.pem')
// }, app);



// app.listen(2000, () => {
//     console.log('Server Up Running @2000')
// })

app.listen(PORT, () => console.log('Server Up Running:',PORT))

//sslServer.listen(3443, () => console.log('Secure Server Started on 3443'))